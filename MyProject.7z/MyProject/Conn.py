import pymysql


class MysqlClass:
    SHOW_SQL = False
    def __init__(self, host='127.0.0.1', port=3306, user='root', password='11546', db='yiqing', charset='utf8'):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.db = db
        self.charset = charset

    # 建立连接
    def get_con(self):
            conn = pymysql.connect(host=self.host, user=self.user, passwd=self.password, db=self.db, port=self.port, charset=self.charset)
            return conn
