import re
import pandas
import numpy as np
from jieba.analyse import extract_tags
from .Conn import MysqlClass
aa= MysqlClass()
conn = MysqlClass.get_con(aa)

# 2/折线图(Line)
def line_data():
    aa.get_con()
    df1 = pandas.read_sql("""
           SELECT distinct update_time,sum(confirmed_add) 
           FROM covid_data 
           where confirmed_add>=0 and update_time!="2020-02-13" 
           group by update_time order by update_time """, conn)
    uptime = list(df1['update_time'])
    data_x = []
    for i in uptime:
        a = i.day  # 取datetime数据的day
        data_x.append(a)
    data_y = list(df1['sum(confirmed_add)'].astype('int'))
    # conn.close()
    return data_x, data_y


# 3/散点图(Scatter)
def scatter_data():
    # 3.查询各省市从湖北迁入的人口比例与该省累计确诊人数的关系，绘制一个散点图(Scatter)。
    # 数据来源为表migrate_data和表covid_data。data_x为各省市从湖北迁入的人口占比，
    # data_y为各省市累计确诊人数（截止到2020年2月29日）。
    # conn = MysqlClass().get_con()
    df2 = pandas.read_sql("""
           SELECT  value,sum(confirmed_count)
           FROM migrate_data, covid_data
           where update_time='2020-02-29' and target_province_name=province_name 
           and source_province_name='湖北省' group by value """, conn)
    list2 = []
    list2.append(list(df2['value']))
    list2.append(list(df2['sum(confirmed_count)']))
    dier = pandas.DataFrame(list2)
    data3 = []
    for i in range(30):
        data3.append(list(dier[i]))
    # conn.close()
    return data3


# 4/仪表盘(Gauge)
def gauge_data():
    # 4.查询全国感染新冠肺炎的死亡率，绘制一个仪表盘(Gauge)。
    # 数据来源为表covid_data，死亡率 = 全国新冠肺炎累计死亡人数 / 全国累计确诊人数（截止到2020年2月29日）。
    # 全国新冠肺炎累计死亡人数
    # conn = MysqlClass().get_con()
    data_x = """SELECT sum(dead_count) FROM  covid_data  where update_time='2020-02-29' """
    # 全国累计确诊人数
    data_y = """SELECT sum(confirmed_count) FROM  covid_data  where update_time='2020-02-29' """
    cur = conn.cursor()
    cur.execute(data_x)  # 执行sql语句
    data1 = cur.fetchall()
    data_x = list(data1)
    cur.execute(data_y)  # 执行sql语句
    data2 = cur.fetchall()
    data_y = list(data2)
    # 死亡率 = 全国新冠肺炎累计死亡人数 / 全国累计确诊人数（截止到2020年2月29日）
    data_z = np.true_divide(np.array(data_x), np.array(data_y))
    y_data = []
    for k in data_z:  # 不支持Decimal将其转换为float
        y_data.append(float(k))
    data_y = round(y_data[0] * 100, 2)
    # conn.close()
    return data_y


# 5/地图(Map)。
def map_data():
    # # 5.查询全国各省市的累计确诊人数，绘制一个地图(Map)。
    # # 数据来源为表covid_data，attr为各个省市的名称（地图中的名称）,value为对应该省市的累计确诊人数（截止到2020年2月29日）
    # conn = MysqlClass().get_con()
    sql = """SELECT province_name,SUM(confirmed_count) FROM `covid_data` 
               where update_time = '2020-02-29' GROUP BY province_name"""
    cur = conn.cursor()
    cur.execute(sql)  # 执行sql语句
    data = cur.fetchall()
    data5 = []
    for i in data:
        dic = {}
        dic["name"] = i[0].strip("省市自治区回族壮族维吾尔族")
        dic["value"] = int(i[1])
        data5.append(dic)
    return data5


# 6/迁徙图（GeoLine）
def geoLine_data():
    # 6.查询从湖北省迁入到各省市的人口占比数据，绘制一个地理坐标系线图（GeoLine）。
    # 数据来源为表migrate_data。

    sql_map = """ select longitude,latitude,value from
                  (select * from area_china where level=1 and name not in("湖北省","香港特别行政区","澳门特别行政区","台湾省")) a join ( select * from migrate_data where source_province_name="湖北省") b on a.name=b.target_province_name """
    cur = conn.cursor()
    cur.execute(sql_map)  # 执行sql语句
    data1 = cur.fetchall()
    sql_map1 = """ select longitude,latitude from area_china where level=1 and name ="湖北省" """
    cur.execute(sql_map1)  # 执行sql语句
    data2 = cur.fetchall()
    hu_bei = list(data2[0])  # 湖北坐标
    name = ["coords"]
    name1 = ["value"]
    map3 = []
    map5 = []
    for i in data1:
        map1 = []
        map2 = []
        map1.append(hu_bei)
        map1.append(list(i[:2]))  # 各省坐标
        map2.append(map1)
        c = dict(zip(name, map2))
        map3.append(c)
        map4 = []
        map4.append(list(i))
        c1 = dict(zip(name1, map4))
        map5.append(c1)
    print(map3)
    print(map5)
    return map3, map5


# 7/饼图(Pie)
def pie_data():
    # 7.统计每个新闻媒体发布的所有新闻的数量，绘制一个饼图(Pie)，数据来源为news_info。
    data_x = """SELECT count(news_title)  FROM news_info  Group By news_source """
    cur = conn.cursor()
    cur.execute(data_x)  # 执行sql语句
    data1 = cur.fetchall()
    data_x =list(data1)
    data_y = """SELECT distinct(news_source)  FROM news_info   """
    cur = conn.cursor()
    cur.execute(data_y)  # 执行sql语句
    data1 = cur.fetchall()
    data_y =list(data1)
    return data_x,data_y


# 8/主题河流图(ThemeRiver)
def themeRiver_data():
    # # 8.统计每个新闻媒体每天发布的新闻的数量，绘制一个主题河流图(ThemeRiver)，数据来源为news_info。
    # conn = MysqlClass().get_con()
    data_x = """SELECT count(news_title)  FROM news_info  Group By news_source """
    # print("待执行的sql语句：", data_x)
    cur = conn.cursor()
    cur.execute(data_x)  # 执行sql语句
    data1 = cur.fetchall()
    # data_x = list(data1)
    # print(data_x)
    data_x = []
    for i in list(data1):
        # print(list(i))
        s = list(i)
        data_x += s
    # print(data_x)

    data_y = """SELECT publish_time ,count(news_title), news_source
                       FROM news_info
                       where publish_time
                       BETWEEN '2020-02-01' AND '2020-02-29'
                       Group By  publish_time ,news_source"""
    # print("待执行的sql语句：", data_y)
    cur = conn.cursor()
    cur.execute(data_y)  # 执行sql语句
    data2 = cur.fetchall()

    # data2 = aa.get_close(data_y)

    # print(data1)
    # 将嵌套的元祖转为嵌套的列表
    def yielder(x):
        for y in x:
            if isinstance(y, tuple):
                yield from yielder(y)
            else:
                yield y

    data_8 = [[*yielder(e)] for e in data2]
    # print(data_8)
    # conn.close()
    return data_8


# 9/词云图(WordCloud)
def wordCloud_data():
    # # # 9.从所有的新闻概要(news_info. news_summary)中，找出tf-idf权重值最大的100个单词，
    # # # 用来绘制一个词云图(WordCloud)，数据来源为news_info。注意数字不做统计。
    # conn = MysqlClass().get_con()
    data_x = """SELECT  news_summary FROM news_info  """
    # print("待执行的sql语句：", data_x)
    cur = conn.cursor()
    cur.execute(data_x)  # 执行sql语句
    data1 = cur.fetchall()
    # print(list(data1))
    # 提取出所有的新闻
    data_x = []
    for i in list(data1):
        # print(list(i))
        s = list(i)
        data_x += s
    data_x = ''.join(data_x)
    # print(data_x)

    f = open('test.txt', 'w')
    f.writelines(data_x)
    f.close()
    for line in open('test.txt', encoding='gbk'):
        line.strip('\n')
        line = re.sub("[A-Za-z\：\0-9\·\—\，\、\；\。\“ \”]", "", line)
    result = extract_tags(sentence=line, withWeight=True, topK=100)
    # print(result)
    word2 = []
    for i, j in result:
        word2.append((i, j))
    a = dict(word2)
    print(dict(word2))
    print("---------------")
    c = []
    # 将字典转为json数据
    data9 = ""
    for i, j in a.items():
        import json
        b = json.dumps({'name': i, 'value': j}, sort_keys=True, indent=4,
                       ensure_ascii=False)  # ensure_ascii=False 解决中文乱码问题
        data9 += b + ','
    return data9

































