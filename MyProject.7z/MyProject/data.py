from django.shortcuts import render
from MyProject.processing import line_data, scatter_data, gauge_data, map_data, wordCloud_data,\
    themeRiver_data, pie_data,geoLine_data
def do_data(request):
        # 2/折线图(Line)
        line_data()
        # 3/散点图(Scatter)
        scatter_data()
        # 4/仪表盘(Gauge)
        gauge_data()
        # 5/地图(Map)。
        map_data()
        # 6/迁徙图（GeoLine）
        geoLine_data()
        # 7/饼图(Pie)
        pie_data()
        # 8/主题河流图(ThemeRiver)
        themeRiver_data()
        # 9/词云图(WordCloud)
        wordCloud_data()
        # conn.close()
        return render(request, "index1.html",
        context={"data1":gauge_data() , "data_2_x": line_data()[0], "data_2_y": line_data()[1],
                 "data3": scatter_data(), "data5": map_data(),"data_6_x": geoLine_data()[0],"data_6_y": geoLine_data()[1],
                 "data8": themeRiver_data(), "data9": wordCloud_data()})
