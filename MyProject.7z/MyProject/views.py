from django.contrib import messages
from django.http import HttpResponseRedirect
from django.shortcuts import render
from pymysql import Connect
from .Conn import MysqlClass
aa= MysqlClass()
conn = MysqlClass.get_con(aa)

def do_login(request):
    # conn = MysqlClass().get_con()
    username = request.POST["username"]
    password = request.POST.get("password")
    print("用户名和密码分别是：", username, password)
    # sql = """SELECT * FROM emp where name = '""" + username + """' and pwd = '""" + password + """'"""
    sql = """SELECT * FROM user_info where username = %s and password = %s"""
    print("待执行的sql语句：", sql)
    cur = conn.cursor()
    cur.execute(sql, (username, password))#执行sql语句
    data = cur.fetchall()
    print("获取到的数据：", data)
    if len(data) == 1:
         return HttpResponseRedirect('/data')
    if len(data)== 0:
           messages.error(request, "账号或密码错误！，请重新输入")
           return render(request, "login.html")
#注册逻辑处理
def register(request):
    conn = MysqlClass().get_con()
    user_id = request.POST.get("user_id")
    username = request.POST["username"]
    password = request.POST.get("password")
    sql = """SELECT * FROM user_info where  user_id=%s and username = %s and password = %s """
    sql1="""SELECT * FROM user_info where username = %s """
    sql2="""insert into user_info(user_id,username,password) values(%s, %s,%s)"""
    print("待执行的sql语句：", sql)
    cur = conn.cursor()
    cur.execute(sql, (user_id,username, password))

    data = cur.fetchall()
    print("获取到的数据：", data)

    if len(data) == 1:

          messages.error(request,"账户已存在")#提示框的信息
          return render(request,"register.html")#在提示框点击确认后返回到register.html
    cur.execute(sql1, (username))

    data1=cur.fetchall()
    if len(data1) ==1 and len(password)!=0 and len(user_id)!=0:
        messages.error(request, "该用户名已被注册！，请重新输入")
        return render(request, "register1.html")
    if len(data)==0:
        cur.execute(sql2, (username, password,user_id))
        conn.commit()#不提交事务则数据插入不成功
        messages.error(request, "注册成功，请登录！")  # 提示框的信息
        return render(request, "login.html")#render为渲染变量，为了传递值渲染html




